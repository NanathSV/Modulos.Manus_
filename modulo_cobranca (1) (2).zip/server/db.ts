import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, trainingResults, InsertTrainingResult, trainingCompletions, InsertTrainingCompletion } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function saveTrainingResult(result: InsertTrainingResult): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot save training result: database not available");
    return;
  }

  try {
    await db.insert(trainingResults).values(result);
  } catch (error) {
    console.error("[Database] Failed to save training result:", error);
    throw error;
  }
}

export async function saveTrainingCompletion(completion: InsertTrainingCompletion): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot save training completion: database not available");
    return;
  }

  try {
    await db.insert(trainingCompletions).values(completion);
  } catch (error) {
    console.error("[Database] Failed to save training completion:", error);
    throw error;
  }
}

export async function getTrainingCompletions() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get training completions: database not available");
    return [];
  }

  try {
    const completions = await db
      .select({
        id: trainingCompletions.id,
        userId: trainingCompletions.userId,
        userName: users.name,
        userEmail: users.email,
        totalCorrect: trainingCompletions.totalCorrect,
        totalQuestions: trainingCompletions.totalQuestions,
        finalScore: trainingCompletions.finalScore,
        completedAt: trainingCompletions.completedAt,
        createdAt: trainingCompletions.createdAt,
      })
      .from(trainingCompletions)
      .innerJoin(users, eq(trainingCompletions.userId, users.id))
      .orderBy(desc(trainingCompletions.completedAt));

    return completions;
  } catch (error) {
    console.error("[Database] Failed to get training completions:", error);
    throw error;
  }
}

export async function getTrainingResultsByUserId(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get training results: database not available");
    return [];
  }

  try {
    const results = await db
      .select()
      .from(trainingResults)
      .where(eq(trainingResults.userId, userId))
      .orderBy(desc(trainingResults.completedAt));

    return results;
  } catch (error) {
    console.error("[Database] Failed to get training results:", error);
    throw error;
  }
}


export async function getTrainingHistoryByUserId(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get training history: database not available");
    return [];
  }

  try {
    const history = await db
      .select({
        id: trainingCompletions.id,
        totalCorrect: trainingCompletions.totalCorrect,
        totalQuestions: trainingCompletions.totalQuestions,
        finalScore: trainingCompletions.finalScore,
        totalTimeSpent: trainingCompletions.totalTimeSpent,
        completedAt: trainingCompletions.completedAt,
      })
      .from(trainingCompletions)
      .where(eq(trainingCompletions.userId, userId))
      .orderBy(desc(trainingCompletions.completedAt));

    return history;
  } catch (error) {
    console.error("[Database] Failed to get training history:", error);
    throw error;
  }
}

export async function getCompletionById(completionId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get completion: database not available");
    return undefined;
  }

  try {
    const completion = await db
      .select()
      .from(trainingCompletions)
      .where(eq(trainingCompletions.id, completionId))
      .limit(1);

    return completion.length > 0 ? completion[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get completion:", error);
    throw error;
  }
}

export async function getResultsByCompletionId(completionId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get results: database not available");
    return [];
  }

  try {
    const completion = await getCompletionById(completionId);
    if (!completion) return [];

    const results = await db
      .select()
      .from(trainingResults)
      .where(eq(trainingResults.userId, completion.userId))
      .orderBy(desc(trainingResults.completedAt))
      .limit(5);

    return results;
  } catch (error) {
    console.error("[Database] Failed to get results:", error);
    throw error;
  }
}
