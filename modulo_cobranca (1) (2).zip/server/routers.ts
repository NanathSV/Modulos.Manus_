import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { saveTrainingResult, saveTrainingCompletion, getTrainingCompletions, getTrainingResultsByUserId, getTrainingHistoryByUserId, getCompletionById, getResultsByCompletionId } from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  training: router({
    saveResult: protectedProcedure
      .input(z.object({
        sectionId: z.number(),
        sectionTitle: z.string(),
        correctAnswers: z.number(),
        totalQuestions: z.number(),
        score: z.number(),
        answers: z.string(),
        timeSpent: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          await saveTrainingResult({
            userId: ctx.user.id,
            sectionId: input.sectionId,
            sectionTitle: input.sectionTitle,
            correctAnswers: input.correctAnswers,
            totalQuestions: input.totalQuestions,
            score: input.score,
            answers: input.answers,
            timeSpent: input.timeSpent,
          });
          return { success: true };
        } catch (error) {
          console.error("Error saving training result:", error);
          throw error;
        }
      }),

    saveCompletion: protectedProcedure
      .input(z.object({
        totalCorrect: z.number(),
        totalQuestions: z.number(),
        finalScore: z.number(),
        totalTimeSpent: z.number(),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          await saveTrainingCompletion({
            userId: ctx.user.id,
            totalCorrect: input.totalCorrect,
            totalQuestions: input.totalQuestions,
            finalScore: input.finalScore,
            totalTimeSpent: input.totalTimeSpent,
          });
          return { success: true };
        } catch (error) {
          console.error("Error saving training completion:", error);
          throw error;
        }
      }),

    getResults: protectedProcedure
      .query(async ({ ctx }) => {
        try {
          const results = await getTrainingResultsByUserId(ctx.user.id);
          return results;
        } catch (error) {
          console.error("Error getting training results:", error);
          throw error;
        }
      }),
  }),

  admin: router({
    getCompletions: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new Error('Unauthorized: Only admins can access this');
        }
        try {
          const completions = await getTrainingCompletions();
          return completions;
        } catch (error) {
          console.error("Error getting training completions:", error);
          throw error;
        }
      }),

    getUserHistory: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new Error('Unauthorized: Only admins can access this');
        }
        try {
          const history = await getTrainingHistoryByUserId(input.userId);
          return history;
        } catch (error) {
          console.error("Error getting user history:", error);
          throw error;
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;

