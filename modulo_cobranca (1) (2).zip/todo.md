# Módulo de Treinamento: Práticas de Cobrança - TODO

## Funcionalidades Planejadas

### Módulo de Treinamento (Concluído)
- [x] Estrutura base com navegação sidebar e conteúdo principal
- [x] Seção 1: Introdução e Visão Geral (com Quiz Rápido)
- [x] Seção 2: Regras de Cobrança - Restituição (com Cenário de Atendimento)
- [x] Seção 3: Regras de Cobrança - Empréstimo Pessoal (com Arrastar e Soltar)
- [x] Seção 4: Comunicação e Abordagem (com Simulação de Diálogo)
- [x] Seção 5: Proteção de Dados e Conformidade (com Quiz Final)
- [x] Sistema de progresso visual (barra de progresso e indicadores)
- [x] Feedback visual para respostas corretas/incorretas (animações)
- [x] Design responsivo (desktop, tablet, mobile)
- [x] Paleta de cores profissional (azul, vermelho, verde, roxo por módulo)
- [x] Ícones informativos e animações suaves
- [x] Temas de cores diferenciados por seção
- [x] Validação de respostas e cálculo de pontuação
- [x] Página de resultado final com resumo de desempenho

### Sistema de Rastreamento (Concluído)
- [x] Adicionar banco de dados (Drizzle ORM)
- [x] Criar schema de usuários e resultados
- [x] Implementar autenticação com email/senha (OAuth Manus)
- [x] Página de login para colaboradores
- [x] Integração de rastreamento de respostas
- [x] Armazenar tentativas múltiplas
- [x] Painel administrativo com lista de participantes
- [x] Visualização de notas e desempenho
- [x] Exportação de dados em CSV/Excel
- [x] Procedimentos tRPC para salvar e recuperar dados
- [x] Tabelas de resultados por seção e conclusão geral

## Alterações Solicitadas
- [x] Mudar pergunta da seção 3 de "Arraste os marcos de tempo..." para "Após quantos dias de atraso pode ocorrer a negativação do cliente?"
- [x] Corrigir título da atividade de "Arrastar e Soltar" para "Vale Lembrar"
- [x] Ajustar opções de resposta para refletir apenas o período de negativação (30 dias)

## Funcionalidade de Cronômetro
- [x] Adicionar coluna de tempo em trainingResults
- [x] Implementar cronômetro por seção no TrainingModule
- [x] Rastrear tempo total do treinamento
- [x] Salvar tempos no banco de dados
- [x] Exibir tempo gasto ao finalizar cada seção
- [x] Mostrar tempos no painel de conclusão
- [x] Adicionar coluna de tempo no painel administrativo
- [x] Calcular tempo médio por seção no admin dashboard

## Funcionalidade de Relatório em PDF
- [x] Criar procedimento tRPC para gerar PDF
- [x] Implementar geração de PDF no cliente
- [x] Adicionar botão de download de PDF na página de conclusão
- [x] Incluir dados do colaborador no relatório
- [x] Adicionar análise por seção no PDF
- [x] Implementar design profissional com cores
- [ ] Adicionar opção de download de relatórios anteriores no painel admin

## Funcionalidade de Histórico de Relatórios
- [x] Criar procedimento tRPC para recuperar histórico de conclusões
- [x] Adicionar tabela de histórico no painel administrativo
- [x] Implementar filtros por colaborador e data
- [x] Adicionar funcionalidade de download de relatórios anteriores
- [ ] Criar gráfico de evolução de desempenho
- [ ] Adicionar estatísticas comparativas entre tentativas

## Correções e Melhorias
- [x] Adicionar link de acesso ao Painel Administrativo na página inicial
- [x] Adicionar menu de navegação para administradores
