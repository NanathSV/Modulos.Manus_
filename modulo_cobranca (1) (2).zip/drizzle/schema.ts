import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Training results table to track user progress and scores
 */
export const trainingResults = mysqlTable("trainingResults", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sectionId: int("sectionId").notNull(),
  sectionTitle: varchar("sectionTitle", { length: 255 }).notNull(),
  correctAnswers: int("correctAnswers").notNull(),
  totalQuestions: int("totalQuestions").notNull(),
  score: int("score").notNull(), // percentage
  answers: text("answers"), // JSON string with all answers
  timeSpent: int("timeSpent").notNull().default(0), // time in seconds
  completedAt: timestamp("completedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TrainingResult = typeof trainingResults.$inferSelect;
export type InsertTrainingResult = typeof trainingResults.$inferInsert;

/**
 * Training completion table to track overall module completion
 */
export const trainingCompletions = mysqlTable("trainingCompletions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  totalCorrect: int("totalCorrect").notNull(),
  totalQuestions: int("totalQuestions").notNull(),
  finalScore: int("finalScore").notNull(), // percentage
  totalTimeSpent: int("totalTimeSpent").notNull().default(0), // time in seconds
  completedAt: timestamp("completedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TrainingCompletion = typeof trainingCompletions.$inferSelect;
export type InsertTrainingCompletion = typeof trainingCompletions.$inferInsert;