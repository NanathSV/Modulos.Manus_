CREATE TABLE `trainingCompletions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`totalCorrect` int NOT NULL,
	`totalQuestions` int NOT NULL,
	`finalScore` int NOT NULL,
	`completedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trainingCompletions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trainingResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sectionId` int NOT NULL,
	`sectionTitle` varchar(255) NOT NULL,
	`correctAnswers` int NOT NULL,
	`totalQuestions` int NOT NULL,
	`score` int NOT NULL,
	`answers` text,
	`completedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trainingResults_id` PRIMARY KEY(`id`)
);
