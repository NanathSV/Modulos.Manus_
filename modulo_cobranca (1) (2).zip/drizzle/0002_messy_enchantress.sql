ALTER TABLE `trainingCompletions` ADD `totalTimeSpent` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `trainingResults` ADD `timeSpent` int DEFAULT 0 NOT NULL;