import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  CheckCircle2,
  XCircle,
  ChevronRight,
  ChevronLeft,
  Menu,
  X,
  Download,
  BarChart3,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { usePdfReport } from "@/hooks/usePdfReport";

// Tipos para as seções
interface Question {
  id: string;
  question: string;
  options: string[];
  correct: number;
  feedback: string;
}

interface Section {
  id: number;
  title: string;
  color: string;
  bgColor: string;
  textColor: string;
  content: string;
  activityType:
    | "quiz"
    | "scenario"
    | "dragdrop"
    | "dialog"
    | "final-quiz";
  questions?: Question[];
}

// Dados das seções
const sections: Section[] = [
  {
    id: 1,
    title: "Introdução e Visão Geral",
    color: "from-blue-600 to-cyan-600",
    bgColor: "bg-blue-50",
    textColor: "text-blue-900",
    content: `
      <h2 class="text-2xl font-bold mb-4">Bem-vindo ao Módulo de Treinamento</h2>
      <p class="mb-4">Este módulo foi desenvolvido para capacitar os colaboradores a entender e aplicar as práticas de cobrança da empresa de forma clara, empática e em conformidade com as políticas internas.</p>
      <div class="bg-white rounded-lg p-4 border-l-4 border-blue-600 mb-4">
        <h3 class="font-bold mb-2">🎯 Objetivos:</h3>
        <ul class="list-disc list-inside space-y-2">
          <li>Compreender a importância da cobrança como suporte ao cliente</li>
          <li>Aplicar as regras de cobrança com ética e empatia</li>
          <li>Reduzir a inadimplência e manter relacionamento positivo</li>
          <li>Proteger dados e garantir conformidade</li>
        </ul>
      </div>
      <div class="bg-white rounded-lg p-4 border-l-4 border-cyan-600">
        <h3 class="font-bold mb-2">💡 Conceito Chave:</h3>
        <p>A cobrança não é punição, mas um processo de suporte ao cliente para regularizar sua situação financeira. Sempre com profissionalismo, respeito e empatia.</p>
      </div>
    `,
    activityType: "quiz",
    questions: [
      {
        id: "q1",
        question:
          "O principal objetivo da cobrança é punir o cliente pelo atraso.",
        options: ["Verdadeiro", "Falso"],
        correct: 1,
        feedback:
          "Correto! O objetivo é auxiliar na regularização e recuperar o crédito, não punir.",
      },
    ],
  },
  {
    id: 2,
    title: "Regras de Cobrança - Restituição",
    color: "from-red-600 to-orange-600",
    bgColor: "bg-red-50",
    textColor: "text-red-900",
    content: `
      <h2 class="text-2xl font-bold mb-4">Regras de Cobrança - Restituição</h2>
      <div class="space-y-4">
        <div class="bg-white rounded-lg p-4 border-l-4 border-red-600">
          <h3 class="font-bold mb-2">📋 Regra Geral</h3>
          <p>Cliente que não quitou após a data de vencimento está sujeito à cobrança.</p>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-orange-600">
          <h3 class="font-bold mb-2">⚡ Prioridade de Quitação</h3>
          <p>Qualquer valor de restituição que caia na Celcoin quita primeiro a dívida de <strong>2025</strong>, independentemente do ano da dívida ou do lote de restituição.</p>
          <p class="mt-2 text-sm italic">Exemplo: Cliente recebeu R$ 200,00 de restituição de 2024 em julho/25. Esse valor será usado para quitar 2025.</p>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-red-600">
          <h3 class="font-bold mb-2">🏦 Caso Específico - Valores Retidos no BB</h3>
          <ul class="list-disc list-inside space-y-2 mt-2">
            <li><strong>Triagem:</strong> Verificar se o cliente já está ciente ou resgatou o valor</li>
            <li><strong>Ação:</strong> Ajudar ativamente no processo de resgate durante o atendimento</li>
            <li><strong>Multa:</strong> Cliente só está sujeito à cobrança de multa APÓS conseguir fazer o resgate</li>
            <li><strong>PIX:</strong> Se o app mostrar juros após resgate, cliente pode pagar via financeiro@velotax.com.br</li>
          </ul>
        </div>
      </div>
    `,
    activityType: "scenario",
    questions: [
      {
        id: "s1",
        question:
          "Um cliente liga dizendo que o valor da restituição está preso no Banco do Brasil e o app está cobrando multa. Qual a melhor abordagem?",
        options: [
          "Dizer que a multa é devida e que ele precisa pagar.",
          "Pedir para ele ligar para o BB para resolver.",
          "Informar que a multa só é aplicada após o resgate e oferecer ajuda imediata para tentar resgatar o valor junto com ele.",
        ],
        correct: 2,
        feedback:
          "Correto! Você reforçou o papel de suporte e aplicou corretamente a regra de que a multa só incide após o resgate.",
      },
    ],
  },
  {
    id: 3,
    title: "Regras de Cobrança - Empréstimo Pessoal",
    color: "from-green-600 to-emerald-600",
    bgColor: "bg-green-50",
    textColor: "text-green-900",
    content: `
      <h2 class="text-2xl font-bold mb-4">Regras de Cobrança - Empréstimo Pessoal</h2>
      <div class="space-y-4">
        <div class="bg-white rounded-lg p-4 border-l-4 border-green-600">
          <h3 class="font-bold mb-2">📊 Estrutura em Duas Fases</h3>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
            <div class="bg-green-50 p-3 rounded">
              <p class="font-bold text-green-700">Fase 1: Pré-Cobrança</p>
              <p class="text-sm mt-1">Lembretes suaves (push, e-mail, WhatsApp) antes do vencimento</p>
            </div>
            <div class="bg-orange-50 p-3 rounded">
              <p class="font-bold text-orange-700">Fase 2: Cobrança</p>
              <p class="text-sm mt-1">Ações após o atraso (até 60 dias)</p>
            </div>
          </div>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-emerald-600">
          <h3 class="font-bold mb-2">📞 Ações de Cobrança (Atrasados)</h3>
          <div class="space-y-2 mt-2">
            <div class="flex items-start gap-2">
              <span class="font-bold text-emerald-600">1-60 dias:</span>
              <span>Contato diário por telefone (manhã, tarde, noite)</span>
            </div>
            <div class="flex items-start gap-2">
              <span class="font-bold text-emerald-600">30 dias:</span>
              <span>Negativação</span>
            </div>
            <div class="flex items-start gap-2">
              <span class="font-bold text-emerald-600">30+ dias:</span>
              <span>Descontos em encargos (conforme ticket médio)</span>
            </div>
            <div class="flex items-start gap-2">
              <span class="font-bold text-emerald-600">60+ dias:</span>
              <span>Protesto em cartório (SP, dívidas ≥ R$800, com contato prévio)</span>
            </div>
            <div class="flex items-start gap-2">
              <span class="font-bold text-emerald-600">Qualquer momento:</span>
              <span>Pagamento parcial mínimo R$50 para estimular regularização</span>
            </div>
          </div>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-green-600">
          <h3 class="font-bold mb-2">💳 Métodos de Pagamento</h3>
          <p class="text-sm mt-2">PIX (prioritário) • Boleto (alternativa) • Cartão de Crédito (após ≥ 5 dias de atraso)</p>
        </div>
      </div>
    `,
    activityType: "dragdrop",
    questions: [
      {
        id: "dd1",
        question:
          "Após quantos dias de atraso pode ocorrer a negativação do cliente?",
        options: [
          "15 dias",
          "30 dias",
          "60 dias",
        ],
        correct: 1,
        feedback:
          "Perfeito! Você identificou corretamente que a negativação ocorre após 30 dias de atraso.",
      },
    ],
  },
  {
    id: 4,
    title: "Comunicação e Abordagem",
    color: "from-purple-600 to-pink-600",
    bgColor: "bg-purple-50",
    textColor: "text-purple-900",
    content: `
      <h2 class="text-2xl font-bold mb-4">Comunicação e Abordagem</h2>
      <div class="space-y-4">
        <div class="bg-white rounded-lg p-4 border-l-4 border-purple-600">
          <h3 class="font-bold mb-2">⏱️ Pequeno Atraso (até 30 dias)</h3>
          <div class="bg-purple-50 p-3 rounded mt-2 space-y-2">
            <p><strong>Pontos-Chave para o Agente:</strong></p>
            <ul class="list-disc list-inside text-sm space-y-1">
              <li>As mensagens de cobrança são automáticas do sistema</li>
              <li>O pagamento é feito normalmente pelo app Velotax</li>
              <li>O canal de atendimento NÃO realiza negociações nem descontos</li>
              <li>Se o cliente quiser negociar, deve ser orientado a acessar o app</li>
            </ul>
          </div>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-pink-600">
          <h3 class="font-bold mb-2">💬 O que Dizer ao Cliente</h3>
          <div class="bg-pink-50 p-3 rounded mt-2 italic border-l-2 border-pink-600">
            <p>"Essas mensagens são automáticas e fazem parte do nosso lembrete de pagamento. Você pode regularizar tudo direto pelo app Velotax — lá aparecem as opções e os valores atualizados."</p>
          </div>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-purple-600">
          <h3 class="font-bold mb-2">🎯 Orientações de Pagamento</h3>
          <ul class="list-disc list-inside space-y-2 mt-2 text-sm">
            <li>Reforçar o uso do app para pagamentos automáticos</li>
            <li>PIX para casos específicos (BB Retido) onde o valor no app pode estar incorreto</li>
            <li>Sempre manter tom profissional, respeitoso e empático</li>
          </ul>
        </div>
      </div>
    `,
    activityType: "dialog",
    questions: [
      {
        id: "d1",
        question:
          "Complete o diálogo: Cliente reclama de uma mensagem de cobrança automática, mas só tem 15 dias de atraso.",
        options: [
          "Essas mensagens são [automáticas] e fazem parte do nosso lembrete de pagamento. Para regularizar, você pode acessar o app Velotax. Lá, você encontra as opções e os valores [atualizados] para quitação.",
          "Você tem razão em reclamar. Vou cancelar essa mensagem para você.",
          "Você precisa pagar agora, senão vamos negativar sua conta.",
        ],
        correct: 0,
        feedback:
          "Excelente! Você aplicou corretamente a abordagem para pequenos atrasos, reforçando que as mensagens são automáticas e orientando o cliente para o app.",
      },
    ],
  },
  {
    id: 5,
    title: "Proteção de Dados e Conformidade",
    color: "from-indigo-600 to-blue-600",
    bgColor: "bg-indigo-50",
    textColor: "text-indigo-900",
    content: `
      <h2 class="text-2xl font-bold mb-4">Proteção de Dados e Conformidade</h2>
      <div class="space-y-4">
        <div class="bg-white rounded-lg p-4 border-l-4 border-indigo-600">
          <h3 class="font-bold mb-2">🔒 LGPD na Cobrança</h3>
          <p class="text-sm mt-2">O acesso e uso de dados do cliente (telefone, e-mail, endereço) deve ser estritamente para a finalidade de cobrança e negociação. Qualquer outro uso viola a LGPD.</p>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-blue-600">
          <h3 class="font-bold mb-2">⚠️ Limites da Abordagem</h3>
          <div class="bg-red-50 p-3 rounded mt-2 space-y-2">
            <p class="font-bold text-red-700">PROIBIDO:</p>
            <ul class="list-disc list-inside text-sm space-y-1">
              <li>Expor o cliente a terceiros (vizinhos, colegas de trabalho)</li>
              <li>Usar linguagem ameaçadora ou constrangedora</li>
              <li>Compartilhar informações com pessoas não autorizadas</li>
              <li>Fazer contato fora dos horários permitidos</li>
            </ul>
          </div>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-indigo-600">
          <h3 class="font-bold mb-2">📝 Registro de Interações</h3>
          <p class="text-sm mt-2">A importância de registrar todas as interações e orientações fornecidas ao cliente para fins de auditoria e conformidade. Isso protege tanto o cliente quanto a empresa.</p>
        </div>
        <div class="bg-white rounded-lg p-4 border-l-4 border-blue-600">
          <h3 class="font-bold mb-2">✅ Boas Práticas</h3>
          <ul class="list-disc list-inside space-y-1 text-sm mt-2">
            <li>Sempre se identificar como representante da empresa</li>
            <li>Respeitar a privacidade do cliente</li>
            <li>Documentar todas as orientações e acordos</li>
            <li>Manter confidencialidade das informações</li>
            <li>Cumprir prazos de contato estabelecidos</li>
          </ul>
        </div>
      </div>
    `,
    activityType: "final-quiz",
    questions: [
      {
        id: "fq1",
        question:
          "Em qual situação o agente deve orientar o cliente a pagar via PIX em vez de usar o app?",
        options: [
          "O cliente não quer usar o cartão de crédito.",
          "O cliente está com o valor da restituição retido no BB e o app está mostrando juros indevidos após o resgate.",
          "O cliente quer um desconto que o app não oferece.",
        ],
        correct: 1,
        feedback:
          "Correto! Você identificou corretamente o caso especial onde o PIX é a melhor opção.",
      },
      {
        id: "fq2",
        question:
          "Qual é o prazo para a negativação do cliente na cobrança de Empréstimo Pessoal?",
        options: ["60 dias", "30 dias", "5 dias"],
        correct: 1,
        feedback:
          "Excelente! A negativação ocorre após 30 dias de atraso.",
      },
      {
        id: "fq3",
        question:
          "Qual é a ação PROIBIDA na abordagem de cobrança?",
        options: [
          "Contato diário por telefone",
          "Expor o cliente a terceiros (vizinhos, colegas)",
          "Oferecer pagamento parcial mínimo de R$50",
        ],
        correct: 1,
        feedback:
          "Correto! Expor o cliente a terceiros é proibido e viola a LGPD.",
      },
    ],
  },
];

interface SectionTime {
  sectionId: number;
  startTime: number;
  endTime?: number;
}

export default function TrainingModule() {
  const { isAuthenticated, user, loading } = useAuth();
  const [, navigate] = useLocation();
  const [currentSection, setCurrentSection] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [showFeedback, setShowFeedback] = useState<Record<string, boolean>>({});
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [completed, setCompleted] = useState(false);
  const [saving, setSaving] = useState(false);
  const [sectionTimes, setSectionTimes] = useState<Record<number, number>>({}); // section id -> time in seconds
  const [currentSectionStartTime, setCurrentSectionStartTime] = useState<number>(Date.now());
  const [totalStartTime] = useState<number>(Date.now());
  const { generatePdf } = usePdfReport();

  const saveResultMutation = trpc.training.saveResult.useMutation();
  const saveCompletionMutation = trpc.training.saveCompletion.useMutation();

  const section = sections[currentSection];
  const progress = ((currentSection + 1) / sections.length) * 100;

  const handleAnswer = (questionId: string, optionIndex: number) => {
    setAnswers({ ...answers, [questionId]: optionIndex });
    setShowFeedback({ ...showFeedback, [questionId]: true });
  };

  const handleNext = async () => {
    // Save time for current section
    const timeSpent = Math.floor((Date.now() - currentSectionStartTime) / 1000);
    setSectionTimes({ ...sectionTimes, [section.id]: timeSpent });

    if (currentSection < sections.length - 1) {
      setCurrentSection(currentSection + 1);
      setCurrentSectionStartTime(Date.now());
      setShowFeedback({});
    } else {
      await handleCompletion();
    }
  };

  const handleCompletion = async () => {
    if (!isAuthenticated || !user) return;

    setSaving(true);
    try {
      // Save time for current section
      const timeSpent = Math.floor((Date.now() - currentSectionStartTime) / 1000);
      const finalSectionTimes = { ...sectionTimes, [section.id]: timeSpent };

      // Save each section result
      for (const sec of sections) {
        if (sec.questions && sec.questions.length > 0) {
          const correctCount = sec.questions.filter(
            (q) => answers[q.id] === q.correct
          ).length;
          const score = Math.round(
            (correctCount / sec.questions.length) * 100
          );

          await saveResultMutation.mutateAsync({
            sectionId: sec.id,
            sectionTitle: sec.title,
            correctAnswers: correctCount,
            totalQuestions: sec.questions.length,
            score,
            answers: JSON.stringify(
              sec.questions.map((q) => ({
                questionId: q.id,
                answer: answers[q.id],
                correct: q.correct,
              }))
            ),
            timeSpent: finalSectionTimes[sec.id] || 0,
          });
        }
      }

      // Calculate and save final completion
      const totalCorrect = sections.reduce((acc, sec) => {
        return (
          acc +
          (sec.questions?.filter((q) => answers[q.id] === q.correct).length || 0)
        );
      }, 0);

      const totalQuestions = sections.reduce(
        (acc, sec) => acc + (sec.questions?.length || 0),
        0
      );

      const finalScore = Math.round((totalCorrect / totalQuestions) * 100);
      const totalTimeSpent = Math.floor((Date.now() - totalStartTime) / 1000);

      await saveCompletionMutation.mutateAsync({
        totalCorrect,
        totalQuestions,
        finalScore,
        totalTimeSpent,
      });

      setCompleted(true);
      setSectionTimes(finalSectionTimes);
    } catch (error) {
      console.error("Error saving training completion:", error);
      alert("Erro ao salvar os resultados. Por favor, tente novamente.");
    } finally {
      setSaving(false);
    }
  };

  const handlePrevious = () => {
    if (currentSection > 0) {
      // Save time for current section
      const timeSpent = Math.floor((Date.now() - currentSectionStartTime) / 1000);
      setSectionTimes({ ...sectionTimes, [section.id]: timeSpent });

      setCurrentSection(currentSection - 1);
      setCurrentSectionStartTime(Date.now());
      setShowFeedback({});
    }
  };

  const handleDownloadPdf = async () => {
    if (!user) return;

    const totalCorrect = sections.reduce((acc, sec) => {
      return (
        acc +
        (sec.questions?.filter((q) => answers[q.id] === q.correct).length || 0)
      );
    }, 0);

    const totalQuestions = sections.reduce(
      (acc, sec) => acc + (sec.questions?.length || 0),
      0
    );

    const totalTimeSpent = Math.floor((Date.now() - totalStartTime) / 1000);

    const reportData = {
      userName: user.name || "Colaborador",
      userEmail: user.email || "",
      totalCorrect,
      totalQuestions,
      finalScore: Math.round((totalCorrect / totalQuestions) * 100),
      totalTimeSpent,
      completedAt: new Date(),
      sectionResults: sections
        .filter((sec) => sec.questions && sec.questions.length > 0)
        .map((sec) => ({
          sectionId: sec.id,
          sectionTitle: sec.title,
          correctAnswers: sec.questions?.filter(
            (q) => answers[q.id] === q.correct
          ).length || 0,
          totalQuestions: sec.questions?.length || 0,
          score: Math.round(
            ((sec.questions?.filter((q) => answers[q.id] === q.correct).length || 0) /
              (sec.questions?.length || 1)) *
              100
          ),
          timeSpent: sectionTimes[sec.id] || 0,
        })),
    };

    try {
      await generatePdf(reportData);
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
    }
  };

  const isAnswered = section.questions?.every(
    (q) => answers[q.id] !== undefined
  );

  const correctAnswers = section.questions?.filter(
    (q) => answers[q.id] === q.correct
  ).length;

  const totalQuestions = section.questions?.length || 0;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <div className="text-white text-center">
          <p>Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-white">
          <div className="p-8 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">
              Módulo de Treinamento
            </h1>
            <p className="text-gray-600 mb-6">
              Você precisa fazer login para acessar o treinamento.
            </p>
            <Button
              onClick={() => navigate("/")}
              className="w-full bg-blue-600 text-white hover:bg-blue-700"
            >
              Fazer Login
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  if (completed) {
    const totalCorrect = sections.reduce((acc, sec) => {
      return (
        acc +
        (sec.questions?.filter((q) => answers[q.id] === q.correct).length || 0)
      );
    }, 0);

    const totalQuestions = sections.reduce(
      (acc, sec) => acc + (sec.questions?.length || 0),
      0
    );

    const totalTimeSpent = Math.floor((Date.now() - totalStartTime) / 1000);
    const formatTime = (seconds: number) => {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins}m ${secs}s`;
    };

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl bg-white">
          <div className="p-8 text-center">
            <div className="mb-6">
              <CheckCircle2 className="w-20 h-20 text-green-600 mx-auto mb-4" />
              <h1 className="text-3xl font-bold text-gray-900 mb-2">
                Parabéns!
              </h1>
              <p className="text-gray-600">
                Você completou o módulo de treinamento com sucesso!
              </p>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 mb-6">
              <div className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-2">
                {totalCorrect}/{totalQuestions}
              </div>
              <p className="text-gray-600">Respostas Corretas</p>
              <div className="mt-4 w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-gradient-to-r from-blue-600 to-purple-600 h-3 rounded-full transition-all"
                  style={{ width: `${(totalCorrect / totalQuestions) * 100}%` }}
                />
              </div>
              <p className="text-sm text-gray-600 mt-2">
                {Math.round((totalCorrect / totalQuestions) * 100)}% de acerto
              </p>
            </div>

            <div className="space-y-3 mb-6">
              <h2 className="font-bold text-lg text-gray-900">
                Tempos por Seção:
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {sections.map((sec) => (
                  <div
                    key={sec.id}
                    className={`p-3 rounded-lg text-sm font-medium ${sec.bgColor} ${sec.textColor}`}
                  >
                    <div className="flex justify-between items-center">
                      <span>⏱️ {sec.title}</span>
                      <span className="font-bold">{formatTime(sectionTimes[sec.id] || 0)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4 mb-6 border border-purple-200">
              <div className="flex justify-between items-center">
                <span className="font-bold text-gray-900">Tempo Total:</span>
                <span className="text-2xl font-bold text-purple-600">{formatTime(totalTimeSpent)}</span>
              </div>
            </div>

            <div className="space-y-3 mb-6">
              <h2 className="font-bold text-lg text-gray-900">
                Tópicos Abordados:
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {sections.map((sec) => (
                  <div
                    key={sec.id}
                    className={`p-3 rounded-lg text-sm font-medium ${sec.bgColor} ${sec.textColor}`}
                  >
                    ✓ {sec.title}
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Button
                onClick={handleDownloadPdf}
                className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                Baixar Relatório em PDF
              </Button>
              <Button
                onClick={() => {
                  setCurrentSection(0);
                  setAnswers({});
                  setShowFeedback({});
                  setCompleted(false);
                }}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white"
              >
                Reiniciar Módulo
              </Button>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      {/* Header com link de admin */}
      {user?.role === 'admin' && (
        <div className="fixed top-0 right-0 z-50 p-4">
          <Button
            onClick={() => navigate('/admin')}
            className="bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2"
          >
            <BarChart3 className="w-4 h-4" />
            Painel Admin
          </Button>
        </div>
      )}
      <div className="flex h-screen">
        {/* Sidebar */}
        <div
          className={`${
            sidebarOpen ? "w-64" : "w-0"
          } bg-slate-800 text-white transition-all duration-300 overflow-hidden flex flex-col border-r border-slate-700`}
        >
          <div className="p-4 border-b border-slate-700">
            <h1 className="text-lg font-bold">Módulo de Treinamento</h1>
            <p className="text-xs text-slate-400 mt-1">Práticas de Cobrança</p>
            {user?.role === 'admin' && (
              <Button
                onClick={() => navigate('/admin')}
                size="sm"
                className="w-full mt-3 bg-purple-600 hover:bg-purple-700 text-white flex items-center justify-center gap-2"
              >
                <BarChart3 className="w-3 h-3" />
                Painel Admin
              </Button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {sections.map((sec, idx) => (
              <button
                key={sec.id}
                onClick={() => {
                  setCurrentSection(idx);
                  setShowFeedback({});
                }}
                className={`w-full text-left p-3 rounded-lg transition-all ${
                  currentSection === idx
                    ? `bg-gradient-to-r ${sec.color} text-white font-semibold`
                    : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold">{sec.id}</span>
                  <span className="text-xs">{sec.title}</span>
                </div>
              </button>
            ))}
          </div>

          <div className="p-4 border-t border-slate-700">
            <div className="text-xs text-slate-400 mb-2">Progresso</div>
            <Progress value={progress} className="h-2" />
            <p className="text-xs text-slate-400 mt-2">
              {currentSection + 1} de {sections.length}
            </p>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <div
            className={`bg-gradient-to-r ${section.color} text-white p-4 flex items-center justify-between`}
          >
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
              <div>
                <h2 className="text-2xl font-bold">{section.title}</h2>
                <p className="text-sm opacity-90">
                  Seção {currentSection + 1} de {sections.length}
                </p>
              </div>
            </div>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto">
            <div className={`${section.bgColor} min-h-full p-6`}>
              <Card className="bg-white">
                <div className="p-6">
                  {/* Section Content */}
                  <div
                    dangerouslySetInnerHTML={{ __html: section.content }}
                    className="prose prose-sm max-w-none mb-8"
                  />

                  {/* Activity Section */}
                  {section.questions && section.questions.length > 0 && (
                    <div className="mt-8 pt-8 border-t-2 border-gray-200">
                      <h3 className="text-xl font-bold mb-6 text-gray-900">
                        {section.activityType === "quiz" && "✓ Quiz Rápido"}
                        {section.activityType === "scenario" &&
                          "🎯 Cenário de Atendimento"}
                        {section.activityType === "dragdrop" &&
                          "🔄 Vale Lembrar"}
                        {section.activityType === "dialog" &&
                          "💬 Simulação de Diálogo"}
                        {section.activityType === "final-quiz" &&
                          "🏆 Quiz Final"}
                      </h3>

                      <div className="space-y-6">
                        {section.questions.map((question) => (
                          <div
                            key={question.id}
                            className="bg-gray-50 p-4 rounded-lg border border-gray-200"
                          >
                            <p className="font-semibold text-gray-900 mb-4">
                              {question.question}
                            </p>

                            <div className="space-y-2">
                              {question.options.map((option, idx) => (
                                <button
                                  key={idx}
                                  onClick={() =>
                                    handleAnswer(question.id, idx)
                                  }
                                  className={`w-full text-left p-3 rounded-lg border-2 transition-all ${
                                    answers[question.id] === idx
                                      ? idx === question.correct
                                        ? "border-green-500 bg-green-50"
                                        : "border-red-500 bg-red-50"
                                      : "border-gray-200 bg-white hover:border-gray-300"
                                  }`}
                                >
                                  <div className="flex items-center gap-3">
                                    <div
                                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                                        answers[question.id] === idx
                                          ? idx === question.correct
                                            ? "border-green-500 bg-green-500"
                                            : "border-red-500 bg-red-500"
                                          : "border-gray-300"
                                      }`}
                                    >
                                      {answers[question.id] === idx &&
                                        (idx === question.correct ? (
                                          <CheckCircle2
                                            size={16}
                                            className="text-white"
                                          />
                                        ) : (
                                          <XCircle
                                            size={16}
                                            className="text-white"
                                          />
                                        ))}
                                    </div>
                                    <span className="text-gray-900">
                                      {option}
                                    </span>
                                  </div>
                                </button>
                              ))}
                            </div>

                            {showFeedback[question.id] && (
                              <div
                                className={`mt-4 p-3 rounded-lg ${
                                  answers[question.id] === question.correct
                                    ? "bg-green-50 border border-green-200"
                                    : "bg-blue-50 border border-blue-200"
                                }`}
                              >
                                <p className="text-sm font-semibold text-gray-900 mb-1">
                                  {answers[question.id] === question.correct
                                    ? "✓ Resposta Correta!"
                                    : "ℹ️ Informação:"}
                                </p>
                                <p className="text-sm text-gray-700">
                                  {question.feedback}
                                </p>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>

                      {/* Progress for this section */}
                      {totalQuestions > 0 && correctAnswers !== undefined && (
                        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-semibold text-gray-900">
                              Progresso desta seção
                            </span>
                            <span className="text-sm font-bold text-blue-600">
                              {correctAnswers}/{totalQuestions}
                            </span>
                          </div>
                          <Progress
                            value={(correctAnswers / totalQuestions) * 100}
                            className="h-2"
                          />
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </Card>
            </div>
          </div>

          {/* Navigation Footer */}
          <div className="bg-white border-t border-gray-200 p-4 flex items-center justify-between">
            <Button
              onClick={handlePrevious}
              disabled={currentSection === 0}
              variant="outline"
              className="flex items-center gap-2"
            >
              <ChevronLeft size={18} />
              Anterior
            </Button>

            <div className="flex-1 mx-4">
              <Progress value={progress} className="h-2" />
            </div>

            <Button
              onClick={handleNext}
              disabled={!isAnswered || saving}
              className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white"
            >
              {saving ? (
                <>
                  <span className="animate-spin">⏳</span>
                  Salvando...
                </>
              ) : currentSection === sections.length - 1 ? (
                <>
                  Finalizar
                  <ChevronRight size={18} />
                </>
              ) : (
                <>
                  Próximo
                  <ChevronRight size={18} />
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
