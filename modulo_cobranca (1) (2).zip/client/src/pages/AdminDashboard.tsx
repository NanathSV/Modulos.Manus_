import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Download, LogOut, BarChart3, ChevronDown, ChevronUp } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";

interface CompletionData {
  id: number;
  userId: number;
  userName: string | null;
  userEmail: string | null;
  totalCorrect: number;
  totalQuestions: number;
  finalScore: number;
  totalTimeSpent: number;
  completedAt: Date;
  createdAt: Date;
}

export default function AdminDashboard() {
  const { logout } = useAuth();
  const [, navigate] = useLocation();
  const [completions, setCompletions] = useState<CompletionData[]>([]);
  const [expandedUserId, setExpandedUserId] = useState<number | null>(null);
  const [userHistory, setUserHistory] = useState<Record<number, any[]>>({});

  const { data, isLoading, error } = trpc.admin.getCompletions.useQuery();
  const getUserHistoryQuery = trpc.admin.getUserHistory.useQuery;

  useEffect(() => {
    if (data) {
      setCompletions(data as CompletionData[]);
    }
  }, [data]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const handleExpandUser = async (userId: number) => {
    if (expandedUserId === userId) {
      setExpandedUserId(null);
    } else {
      setExpandedUserId(userId);
      if (!userHistory[userId]) {
        try {
          const { data: history } = await trpc.admin.getUserHistory.useQuery({ userId });
          if (history) {
            setUserHistory({ ...userHistory, [userId]: history });
          }
        } catch (error) {
          console.error("Erro ao carregar histórico:", error);
        }
      }
    }
  };

  const exportToCSV = () => {
    if (completions.length === 0) {
      alert("Nenhum dado para exportar");
      return;
    }

    const headers = [
      "ID",
      "Nome do Colaborador",
      "Email",
      "Corretas",
      "Total",
      "Pontuação (%)",
      "Tempo Total",
      "Data de Conclusão",
    ];

    const rows = completions.map((item) => [
      item.id,
      item.userName || "N/A",
      item.userEmail || "N/A",
      item.totalCorrect,
      item.totalQuestions,
      item.finalScore,
      formatTime(item.totalTimeSpent),
      new Date(item.completedAt).toLocaleString("pt-BR"),
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map((row) => row.map((cell) => `"${cell}"`).join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);

    link.setAttribute("href", url);
    link.setAttribute("download", `relatorio_treinamento_${new Date().getTime()}.csv`);
    link.style.visibility = "hidden";

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Painel Administrativo</h1>
            <p className="text-slate-400 mt-1">Resultados de Treinamento</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={exportToCSV}
              className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
            >
              <Download className="w-4 h-4" />
              Exportar CSV
            </Button>
            <Button
              onClick={() => {
                logout();
                navigate("/");
              }}
              className="bg-red-600 hover:bg-red-700 text-white flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total de Conclusões</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{completions.length}</p>
              </div>
              <BarChart3 className="w-10 h-10 text-blue-600 opacity-20" />
            </div>
          </Card>

          <Card className="bg-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pontuação Média</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {completions.length > 0
                    ? Math.round(
                        completions.reduce((acc, c) => acc + c.finalScore, 0) /
                          completions.length
                      )
                    : 0}
                  %
                </p>
              </div>
              <BarChart3 className="w-10 h-10 text-green-600 opacity-20" />
            </div>
          </Card>

          <Card className="bg-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Aprovados (80%+)</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {completions.filter((c) => c.finalScore >= 80).length}
                </p>
              </div>
              <BarChart3 className="w-10 h-10 text-green-600 opacity-20" />
            </div>
          </Card>

          <Card className="bg-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tempo Médio</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">
                  {completions.length > 0
                    ? formatTime(
                        Math.round(
                          completions.reduce((acc, c) => acc + c.totalTimeSpent, 0) /
                            completions.length
                        )
                      )
                    : "0m"}
                </p>
              </div>
              <BarChart3 className="w-10 h-10 text-purple-600 opacity-20" />
            </div>
          </Card>
        </div>

        {/* Results Table */}
        <Card className="bg-white">
          <div className="p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Resultados de Treinamento</h2>

            {isLoading ? (
              <div className="text-center py-8">
                <p className="text-gray-600">Carregando resultados...</p>
              </div>
            ) : error ? (
              <div className="text-center py-8">
                <p className="text-red-600">Erro ao carregar resultados</p>
              </div>
            ) : completions.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-600">
                  Nenhum resultado de treinamento disponível
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b-2 border-slate-200">
                      <th className="text-left py-3 px-4 font-semibold text-gray-900">
                        Nome
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900">
                        Email
                      </th>
                      <th className="text-center py-3 px-4 font-semibold text-gray-900">
                        Corretas
                      </th>
                      <th className="text-center py-3 px-4 font-semibold text-gray-900">
                        Total
                      </th>
                      <th className="text-center py-3 px-4 font-semibold text-gray-900">
                        Pontuação
                      </th>
                      <th className="text-center py-3 px-4 font-semibold text-gray-900">
                        Tempo Total
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900">
                        Data de Conclusão
                      </th>
                      <th className="text-center py-3 px-4 font-semibold text-gray-900">
                        Histórico
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {completions.map((item, idx) => (
                      <tr
                        key={item.id}
                        className={`border-b border-slate-100 ${
                          idx % 2 === 0 ? "bg-slate-50" : "bg-white"
                        } hover:bg-blue-50 transition-colors`}
                      >
                        <td className="py-3 px-4 text-gray-900 font-medium">
                          {item.userName || "N/A"}
                        </td>
                        <td className="py-3 px-4 text-gray-700">
                          {item.userEmail || "N/A"}
                        </td>
                        <td className="py-3 px-4 text-center text-gray-900 font-medium">
                          {item.totalCorrect}
                        </td>
                        <td className="py-3 px-4 text-center text-gray-700">
                          {item.totalQuestions}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-block px-3 py-1 rounded-full font-semibold text-sm ${
                              item.finalScore >= 80
                                ? "bg-green-100 text-green-800"
                                : item.finalScore >= 60
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                            }`}
                          >
                            {item.finalScore}%
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center text-gray-900 font-medium">
                          {formatTime(item.totalTimeSpent)}
                        </td>
                        <td className="py-3 px-4 text-gray-700 text-sm">
                          {new Date(item.completedAt).toLocaleString("pt-BR")}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleExpandUser(item.userId)}
                            className="flex items-center gap-1"
                          >
                            {expandedUserId === item.userId ? (
                              <ChevronUp className="w-4 h-4" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
