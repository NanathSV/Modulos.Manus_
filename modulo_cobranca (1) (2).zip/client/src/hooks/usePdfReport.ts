import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";

interface ReportData {
  userName: string;
  userEmail: string;
  totalCorrect: number;
  totalQuestions: number;
  finalScore: number;
  totalTimeSpent: number;
  completedAt: Date;
  sectionResults: Array<{
    sectionId: number;
    sectionTitle: string;
    correctAnswers: number;
    totalQuestions: number;
    score: number;
    timeSpent: number;
  }>;
}

export const usePdfReport = () => {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const generatePdf = async (data: ReportData) => {
    try {
      const doc = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      let yPosition = 20;

      // Header
      doc.setFillColor(30, 58, 138); // Azul profundo
      doc.rect(0, 0, pageWidth, 40, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFontSize(24);
      doc.text("Relatório de Treinamento", pageWidth / 2, 15, {
        align: "center",
      } as any);
      doc.setFontSize(11);
      doc.text(
        "Módulo: Práticas de Cobrança",
        pageWidth / 2,
        25,
        { align: "center" } as any
      );

      yPosition = 50;

      // Informações do Colaborador
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(12);
      doc.setFont(undefined as any, "bold");
      doc.text("Informações do Colaborador", 20, yPosition);

      yPosition += 8;
      doc.setFontSize(10);
      doc.setFont(undefined as any, "normal");
      doc.text(`Nome: ${data.userName}`, 20, yPosition);

      yPosition += 6;
      doc.text(`Email: ${data.userEmail}`, 20, yPosition);

      yPosition += 6;
      doc.text(
        `Data de Conclusão: ${new Date(data.completedAt).toLocaleString(
          "pt-BR"
        )}`,
        20,
        yPosition
      );

      yPosition += 12;

      // Resumo de Desempenho
      doc.setFont(undefined as any, "bold");
      doc.setFontSize(12);
      doc.text("Resumo de Desempenho", 20, yPosition);

      yPosition += 8;
      doc.setFont(undefined as any, "normal");
      doc.setFontSize(10);

      // Box de pontuação
      doc.setFillColor(230, 240, 255);
      doc.rect(20, yPosition - 5, pageWidth - 40, 25, "F");

      doc.setTextColor(30, 58, 138);
      doc.setFont(undefined as any, "bold");
      doc.setFontSize(14);
      doc.text(`${data.finalScore}%`, 50, yPosition + 8, { align: "center" } as any);

      doc.setFont(undefined as any, "normal");
      doc.setFontSize(10);
      doc.setTextColor(0, 0, 0);
      doc.text(
        `${data.totalCorrect} de ${data.totalQuestions} questões corretas`,
        50,
        yPosition + 16,
        { align: "center" } as any
      );

      doc.text(`Tempo Total: ${formatTime(data.totalTimeSpent)}`, 120, yPosition + 8);
      doc.text(
        `Status: ${data.finalScore >= 80 ? "Aprovado" : "Revisão Necessária"}`,
        120,
        yPosition + 16
      );

      yPosition += 35;

      // Análise por Seção
      doc.setFont(undefined as any, "bold");
      doc.setFontSize(12);
      doc.text("Análise por Seção", 20, yPosition);

      yPosition += 8;

      // Tabela de seções
      const tableStartY = yPosition;
      const colWidths = [
        pageWidth - 40 - 50 - 30,
        50,
        30,
      ];
      const rowHeight = 8;

      // Cabeçalho da tabela
      doc.setFillColor(30, 58, 138);
      doc.setTextColor(255, 255, 255);
      doc.setFont(undefined as any, "bold");
      doc.setFontSize(9);

      let xPos = 20;
      doc.text("Seção", xPos as any, yPosition + 5);
      xPos += colWidths[0];
      doc.text("Acertos", xPos as any, yPosition + 5, { align: "center" } as any);
      xPos += colWidths[1];
      doc.text("Tempo", xPos as any, yPosition + 5, { align: "center" } as any);

      yPosition += rowHeight + 1;

      // Linhas da tabela
      doc.setTextColor(0, 0, 0);
      doc.setFont(undefined as any, "normal");
      doc.setFontSize(9);

      let alternateColor = false;
      for (const section of data.sectionResults) {
        if (yPosition > pageHeight - 30) {
          doc.addPage();
          yPosition = 20;
          alternateColor = false;
        }

        if (alternateColor) {
          doc.setFillColor(240, 240, 240);
          doc.rect(20, yPosition - 6, pageWidth - 40, rowHeight, "F");
        }

        xPos = 20;
        doc.text(section.sectionTitle, xPos as any, yPosition);
        xPos += colWidths[0];
        doc.text(
          `${section.correctAnswers}/${section.totalQuestions}`,
          xPos as any,
          yPosition,
          { align: "center" } as any
        );
        xPos += colWidths[1];
        doc.text(formatTime(section.timeSpent), xPos as any, yPosition, {
          align: "center",
        } as any);

        yPosition += rowHeight;
        alternateColor = !alternateColor;
      }

      yPosition += 10;

      // Observações
      doc.setFont(undefined as any, "bold");
      doc.setFontSize(10);
      doc.text("Observações", 20, yPosition);

      yPosition += 6;
      doc.setFont(undefined as any, "normal");
      doc.setFontSize(9);

      const observations =
        data.finalScore >= 80
          ? "Excelente desempenho! Você domina bem as práticas de cobrança."
          : "Recomenda-se revisão dos tópicos com menor desempenho.";

      const splitObservations = doc.splitTextToSize(observations, pageWidth - 40);
      doc.text(splitObservations as any, 20, yPosition);

      // Footer
      yPosition = pageHeight - 15;
      doc.setFontSize(8);
      doc.setTextColor(128, 128, 128);
      doc.text(
        `Gerado em ${new Date().toLocaleString("pt-BR")}`,
        pageWidth / 2,
        yPosition,
        { align: "center" } as any
      );

      // Salvar PDF
      const fileName = `Relatorio_Treinamento_${data.userName.replace(
        /\s+/g,
        "_"
      )}_${new Date().toISOString().split("T")[0]}.pdf`;
      doc.save(fileName);
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
      throw error;
    }
  };

  return { generatePdf, formatTime };
};
